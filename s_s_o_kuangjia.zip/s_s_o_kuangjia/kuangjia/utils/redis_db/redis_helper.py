import redis

from django.conf import settings

class RedisHelper:
    def __init__(self, host, port, db, password):
        self.__conn = redis.Redis(host, port, db, password)

    def key_set(self,key, value):
        return self.__conn.set(key, value, ex=settings.SSO_EXPIRED_TIME)

    def key_get(self, key):
        value = self.__conn.get(key)
        return value or None

    def key_del(self, *key):
        value = self.__conn.delete(*key)
        return value or None

    def key_exists(self, key):
        return self.__conn.exists(key)


if __name__ == '__main__':
    REDIS_DB = {
        'host': '192.168.20.105',
        'port': 6379,
        'db': 0,
        'password': '123456'
    }
    h = RedisHelper(**REDIS_DB)
    # print(h.key_exists('k1'))
    h.key_set('abc', 'kfsfji2jfkksjfks')
    h.key_del('abc')
