from django.db import models
from datetime import datetime
from django.conf import settings
# Create your models here.

class AuthInfo(models.Model):
    username = models.CharField(max_length=64, verbose_name='已认证用户')
    auth_token = models.CharField(max_length=256, verbose_name='认证口令')
    auth_time = models.DateTimeField(default=datetime.now, verbose_name='认证时间')
    expire_time = models.IntegerField(default=settings.SSO_EXPIRED_TIME, null=True, blank=True, verbose_name='认证有效时间')


    def __str__(self):
        return self.username
