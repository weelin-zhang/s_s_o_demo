from django.conf.urls import url
from django.contrib.auth.views import LoginView as SysLoginView
from django.contrib.auth.views import LogoutView as SysLogoutView
from django.core.urlresolvers import reverse_lazy

from .views import LoginView, check, LogoutView
from .forms import LoginForm

urlpatterns = [

    url(r'^login/$', SysLoginView.as_view(**{"authentication_form": LoginForm, 'template_name': 'accounts/login.html'}), name='login'),
    url(r'^logout/$', SysLogoutView.as_view(**{'next_page': reverse_lazy('accounts:login')}), name='logout'),

    url(r'^auth/login/$', LoginView.as_view(), name='auth_login'),
    url(r'^auth/logout/(?P<authkey>.*)/$', LogoutView.as_view(), name='auth_logout'),
    url(r'^auth/check/(?P<authkey>.*)/$', check, name='auth_check'),
]
