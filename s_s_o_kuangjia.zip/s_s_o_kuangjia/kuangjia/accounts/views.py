from django.shortcuts import render
from django.views.generic.base import View
from django.contrib.auth import authenticate
from .forms import BaseLoginForm

from django.contrib.auth.base_user import make_password
# Create your views here.

from django.http import JsonResponse
from utils.redis_db.redis_helper import RedisHelper
from django.conf import settings
from .models import AuthInfo

redis_helper = RedisHelper(**settings.REDIS_DB)

class LoginView(View):
    def get(self, request):
        form = BaseLoginForm()
        return  render(request, 'accounts/login22.html', locals())




    def post(self, request):
        form = BaseLoginForm(request.POST)
        next = request.GET.get('next', '/')
        if  form.is_valid():
            data = form.cleaned_data
            username = form.cleaned_data['username']
            # check
            _user = authenticate(request, **data)
            print(_user)
            if _user and _user.is_active:
                # 用户类型
                user_type = 's' if _user.is_superuser else  'c'
                # 生成动态token, 作为redis的键值,加密处理
                authtoken = make_password(username)
                # 可以把用户信息放进去
                redis_value = 'logined'
                # 存到redis,默认20mins
                result = redis_helper.key_set(authtoken, redis_value)

                # 记录本次认证到模型
                # 不必删除,因为可能在不同浏览器有同一账户登陆
                # if AuthInfo.objects.filter(username=username):
                #     AuthInfo.objects.get(username=username).delete()

                auth_info = AuthInfo.objects.create(username=username, auth_token=authtoken)


                # authtoken放入cookies
                # 超级用户?

                resp = render(request, 'accounts/success.html', locals())
                return resp


        return render(request, 'accounts/login22.html', locals())


class LogoutView(View):
    '''
    手动触发删除token from redis
    '''
    def get(self, request, authkey):
        print(authkey)
        # 从redis删除
        num = redis_helper.key_del(authkey)

        # 从mysql删除
        try:
            AuthInfo.objects.get(auth_token=authkey).delete()
        except Exception as e:
            print(e)
            pass
        return JsonResponse({"msg": "已退出", "code": 0})



def check(request, authkey):
    print(authkey)
    if redis_helper.key_exists(authkey):
        return JsonResponse({"code": 0, "msg": "已认证"})
    return JsonResponse({"code": 1, "msg": "请重新认证"})


